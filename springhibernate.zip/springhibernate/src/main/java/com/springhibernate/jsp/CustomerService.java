package com.springhibernate.jsp;

import java.util.List;




import com.springhibernate.jsp.model.Customer;
 
 

public interface CustomerService {
 
	public List<Customer> getAllCustomers() ;
 
	
}