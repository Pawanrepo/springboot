package com.springhibernate.jsp;

import java.util.List;

import com.springhibernate.jsp.model.Customer;
 
public interface CustomerDao {
	public List<Customer> getAllCustomers() ;
 
	
}
