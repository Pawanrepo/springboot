package com.springhibernate.jsp;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springhibernate.jsp.model.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}
	
	
	public List<Customer> getAllCustomers() {
		System.out.println("inside dao");
		List<Customer> lt = new ArrayList<Customer>();
	Session session = this.sessionFactory.getCurrentSession();
	String sqlQueries = "select * from customer";
	System.out.println(sqlQueries);
	SQLQuery query = session.createSQLQuery(sqlQueries);
	List<Object[]> rows = query.list();
	for (Object[] row : rows) {
		Customer customer = new Customer();
		System.out.println(row[0].toString());
		System.out.println(row[1].toString());
		customer.setCustomerid(Integer.parseInt(row[0] != null ? row[0].toString() : null));
		customer.setCustomerName(row[1] != null ? row[1].toString() : null);
		
		
		lt.add(customer);

	}

	return lt;
	}
}
